import 'package:flutter/material.dart';

const green = Color(0xFF18B96B);
const dark = Color(0xFF0D1B15);

void main() => runApp(const SuldayoApp());

class SuldayoApp extends StatelessWidget {
  const SuldayoApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'SULDAYO',
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: green), scaffoldBackgroundColor: const Color(0xFFF5FAF7)),
    home: const LoginPage(),
  );
}

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(28), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Container(height: 82, width: 82, decoration: BoxDecoration(color: green, borderRadius: BorderRadius.circular(24)), child: const Icon(Icons.people_alt_rounded, color: Colors.white, size: 44)),
      const SizedBox(height: 22),
      const Text('SULDAYO', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: dark)),
      const Text('Connect • Share • Discover', style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 42),
      const Text('Welcome back', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
      const SizedBox(height: 18),
      field('Email or phone', Icons.person_outline), const SizedBox(height: 14), field('Password', Icons.lock_outline, true),
      Align(alignment: Alignment.centerRight, child: TextButton(onPressed: () {}, child: const Text('Forgot password?'))),
      FilledButton(style: FilledButton.styleFrom(backgroundColor: green, minimumSize: const Size.fromHeight(54), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainShell())), child: const Text('Log In', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17))),
      const SizedBox(height: 14),
      OutlinedButton(style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(54), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SignUpPage())), child: const Text('Create Account')),
    ]))));
  static Widget field(String hint, IconData icon, [bool obscure=false]) => TextField(obscureText: obscure, decoration: InputDecoration(hintText: hint, prefixIcon: Icon(icon), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)));
}

class SignUpPage extends StatelessWidget {
  const SignUpPage({super.key});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Join SULDAYO')), body: ListView(padding: const EdgeInsets.all(24), children: [
    LoginPage.field('Full name', Icons.badge_outlined), const SizedBox(height: 12), LoginPage.field('Username', Icons.alternate_email), const SizedBox(height: 12), LoginPage.field('Email or phone', Icons.mail_outline), const SizedBox(height: 12), LoginPage.field('Password', Icons.lock_outline, true), const SizedBox(height: 18),
    const Text('Date of birth'), const SizedBox(height: 6), const Text('Used to provide age-appropriate safety features.', style: TextStyle(color: Colors.black54)), const SizedBox(height: 22),
    FilledButton(style: FilledButton.styleFrom(backgroundColor: green, minimumSize: const Size.fromHeight(54)), onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainShell())), child: const Text('Create Account')),
  ]));
}

class MainShell extends StatefulWidget { const MainShell({super.key}); @override State<MainShell> createState()=>_MainShellState(); }
class _MainShellState extends State<MainShell> {
  int i=0; final pages=const [HomePage(), ShortsPage(), DiscoverPage(), MessagesPage(), ProfilePage()];
  @override Widget build(BuildContext context)=>Scaffold(appBar: AppBar(title: const Text('SULDAYO', style: TextStyle(fontWeight: FontWeight.w900,color:green)), actions:[IconButton(onPressed:(){},icon:const Icon(Icons.notifications_none)),IconButton(onPressed:(){},icon:const Icon(Icons.search))]), body:pages[i], bottomNavigationBar:NavigationBar(selectedIndex:i,onDestinationSelected:(v)=>setState(()=>i=v),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),NavigationDestination(icon:Icon(Icons.play_circle_outline),selectedIcon:Icon(Icons.play_circle),label:'Shorts'),NavigationDestination(icon:Icon(Icons.favorite_border),selectedIcon:Icon(Icons.favorite),label:'Discover'),NavigationDestination(icon:Icon(Icons.chat_bubble_outline),selectedIcon:Icon(Icons.chat_bubble),label:'Messages'),NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Profile')]));
}

class HomePage extends StatelessWidget { const HomePage({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[Card(child:ListTile(leading:const CircleAvatar(backgroundColor:green,child:Icon(Icons.person,color:Colors.white)),title:const Text('What are you thinking?'))),post('Dayo','Welcome to SULDAYO! 🚀'),post('Amina','New moment ✨'),post('Kola','Who is ready for the weekend? 🔥')]); Widget post(String n,String t)=>Card(margin:const EdgeInsets.only(bottom:14),child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[const CircleAvatar(backgroundColor:green,child:Icon(Icons.person,color:Colors.white)),const SizedBox(width:10),Text(n,style:const TextStyle(fontWeight:FontWeight.bold))]),const SizedBox(height:12),Text(t,style:const TextStyle(fontSize:16)),const SizedBox(height:12),Container(height:150,decoration:BoxDecoration(color:green.withOpacity(.1),borderRadius:BorderRadius.circular(14)),child:const Center(child:Icon(Icons.photo_library_outlined,size:60,color:green))),Row(children:[IconButton(onPressed:(){},icon:const Icon(Icons.favorite_border)),IconButton(onPressed:(){},icon:const Icon(Icons.comment_outlined)),IconButton(onPressed:(){},icon:const Icon(Icons.share_outlined))])]))); }

class ShortsPage extends StatelessWidget { const ShortsPage({super.key}); @override Widget build(BuildContext c)=>PageView.builder(scrollDirection:Axis.vertical,itemCount:8,itemBuilder:(_,i)=>Container(margin:const EdgeInsets.all(10),decoration:BoxDecoration(color:dark,borderRadius:BorderRadius.circular(22)),child:Stack(children:[const Center(child:Icon(Icons.play_circle_fill,color:Colors.white,size:80)),Positioned(left:18,bottom:22,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('@suldayo_user${i+1}',style:const TextStyle(color:Colors.white,fontWeight:FontWeight.bold,fontSize:17)),const Text('Amazing moment 🎬',style:TextStyle(color:Colors.white))])),const Positioned(right:14,bottom:22,child:Column(children:[Icon(Icons.favorite,color:Colors.white,size:30),SizedBox(height:16),Icon(Icons.comment,color:Colors.white,size:30),SizedBox(height:16),Icon(Icons.share,color:Colors.white,size:30)]))])); }

class DiscoverPage extends StatelessWidget { const DiscoverPage({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Discover',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const Text('Find people and communities you may like.',style:TextStyle(color:Colors.black54)),const SizedBox(height:16),...['Aisha','Daniel','Mariam','Samuel'].map((n)=>Card(child:ListTile(leading:const CircleAvatar(backgroundColor:green,child:Icon(Icons.person,color:Colors.white)),title:Text(n,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:const Text('New connection'),trailing:FilledButton(onPressed:(){},child:const Text('Connect')))))]); }
class MessagesPage extends StatelessWidget { const MessagesPage({super.key}); @override Widget build(BuildContext c)=>ListView(children:['Aisha','Daniel','Mariam','Samuel'].map((n)=>ListTile(leading:const CircleAvatar(backgroundColor:green,child:Icon(Icons.person,color:Colors.white)),title:Text(n),subtitle:const Text('Tap to chat'),trailing:const Icon(Icons.chevron_right))).toList()); }
class ProfilePage extends StatelessWidget { const ProfilePage({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(20),children:[const Center(child:CircleAvatar(radius:48,backgroundColor:green,child:Icon(Icons.person,color:Colors.white,size:52))),const SizedBox(height:12),const Center(child:Text('Dayo',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900))),const Center(child:Text('@dayo',style:TextStyle(color:Colors.black54))),const SizedBox(height:22),const Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:[Stat('120','Posts'),Stat('2.4K','Followers'),Stat('310','Following')]),const SizedBox(height:20),const ListTile(leading:Icon(Icons.edit_outlined),title:Text('Edit profile')),const ListTile(leading:Icon(Icons.settings_outlined),title:Text('Settings')),const ListTile(leading:Icon(Icons.shield_outlined),title:Text('Safety & privacy'))]); }
class Stat extends StatelessWidget { final String a,b; const Stat(this.a,this.b,{super.key}); @override Widget build(BuildContext c)=>Column(children:[Text(a,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:20)),Text(b,style:const TextStyle(color:Colors.black54))]); }
